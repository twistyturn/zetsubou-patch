PROJECT ZETSUBOU SCRIPT FOR DANGANRONPA: TRIGGER HAPPY HAVOC
Windows PC patch, version 1.0
==============================================================

This puts Project Zetsubou's 2013 fan translation of Danganronpa into the
Steam version of the game on your Windows PC.

(Playing on a Steam Deck instead? That needs the Steam Deck version.)

You need:
  - Danganronpa: Trigger Happy Havoc from Steam, installed on this PC
    (any drive or Steam library folder works)
  - About 1.5 GB of free space on the drive where the game is installed

The patch contains only text and lettering. It doesn't include any of the
game's own files, so it works on your own copy of the game. Nothing else
needs installing: the patcher brings its own copy of Python (the official
one from python.org) inside the "files" folder.


INSTALLING
----------

1. Unpack the download
   Right-click the patch zip file and choose "Extract All...", then
   "Extract". (Don't run it from inside the zip without extracting -
   it won't work from there.)
   You'll get a folder called "Zetsubou Patch for Danganronpa (Windows)".

2. Close the game
   If Danganronpa is running, close it first.

3. Run the installer
   Open the folder and double-click "Install Zetsubou Patch".

   Windows may show a security warning first, because the file came from
   the internet:
     - "Open File - Security Warning": click "Run".
     - "Windows protected your PC" (a blue box): click "More info",
       then "Run anyway".

   A small window called "Zetsubou Patch" appears, with a progress bar
   and a line saying what it's doing. It takes a few minutes; just let
   it work. (The window can't be closed while it's working. That's on
   purpose, so the game file is never left half-finished.)
   When it's done, the window goes away and a message box says "Done!".
   Click OK.

4. Play
   Start Danganronpa from Steam as usual.

Your existing saves keep working, with or without the patch.

Tip: set the voices to Japanese in the game's Options. Project Zetsubou
translated from the Japanese, so their text matches what you hear. The
English dub was recorded for the official script, so with English voices
the spoken lines often won't match the text on screen.


IF IT DOESN'T START
-------------------

If a message says "You need to unpack the download first", you opened
the installer from inside the zip file. Do step 1, then double-click
"Install Zetsubou Patch" in the new folder.

If double-clicking does nothing at all (wait a few seconds first - the
progress window can take a moment to appear):

  1. Make sure you extracted the zip first (step 1).
  2. Right-click "Install Zetsubou Patch" -> Properties. If there's an
     "Unblock" checkbox at the bottom of the General tab, tick it and
     click OK. Then double-click it again.
  3. If your antivirus program asks about it or blocked it, allow it
     and try again.


GOING BACK TO THE ORIGINAL GAME
-------------------------------

Double-click "Restore Original Game" in the patch folder. It puts back
the original file that the installer kept as a backup.

Steam can also do this: in your Library, right-click Danganronpa ->
Properties -> Installed Files -> "Verify integrity of game files". Note
that this also removes the patch, so if you ever run it by accident,
just run "Install Zetsubou Patch" again.


IF SOMETHING GOES WRONG
-----------------------

The patcher checks everything before it changes anything. If a check
fails, your game is left exactly as it was, and the message tells you
what to do. Common ones:

  - "Danganronpa is running": close the game and try again.
  - "isn't the official Steam version": another mod may be installed.
    Use "Verify integrity of game files" in Steam, then try again.
  - "Not enough free space": free up some space and try again.

Each run is recorded in files\last-run.log inside the patch folder. If
you need help, send that file along.


ABOUT THIS PATCH
----------------

Translation: Project Zetsubou (2013), from their public script release.
This patch carries their script over to the Steam version of the game,
as faithfully as possible. Every change is recorded line by line in the
project files. In short:

  - Lines are Project Zetsubou's, except for a small number of fixes:
    slurs and sexual content that the translation added (and that
    aren't in the Japanese), a few lines that misread the Japanese, and
    puns that didn't survive the first time.
  - Places the Steam version added (School Mode, some extra items and
    menus) keep the official English text, with names and terms
    matched to Project Zetsubou's (Hope's Peak, ElectroiD, Kyouko,
    Super Duper High School...).
  - Control and button instructions keep the official text, so the
    button prompts are always right for your controller or keyboard.
  - On-screen graphics that spell out names and terms were re-lettered
    to match: the student intro cards and gallery icons, name tags,
    chapter titles, the ElectroiD menu and School Rules pages, the dorm
    door nameplates, Naegi's acceptance letter, a few banners, and the
    names on the executions' GAME OVER screens. The
    patch only carries the new lettering; it's painted onto your own
    copy of the game when you install.
  - Epiphany Anagram puzzles are adjusted so Project Zetsubou's answers
    fit (for example, Chapter 2's answer is DID).
  - The opening movie that plays every time the game starts is cut to
    about three seconds, because it can't be skipped with a controller
    on the Steam Deck. (The "Opening" entry in the Movie Gallery is
    shortened too. Restoring the original game brings it back.)

This is a fan project. It isn't affiliated with or endorsed by Spike
Chunsoft, NIS America, or Project Zetsubou. Please support the official
release.

Bundled: Python 3.12.10 embeddable package for Windows, from python.org,
under the Python Software Foundation License; and vpxdec/vpxenc from
libvpx 1.15.2 (the WebM Project's VP8 video codec, used to re-letter the
videos), under the BSD license in files\vpx\.
