@echo off
rem Double-click to put back the original game file.
rem Starts the patcher without a console window (pythonw) and exits right away.
setlocal
if not exist "%~dp0files\python\pythonw.exe" goto notunpacked
if not exist "%~dp0files\windows\windows_patcher.py" goto notunpacked
start "" "%~dp0files\python\pythonw.exe" -I "%~dp0files\windows\windows_patcher.py" restore
exit /b 0

:notunpacked
rem Usually: double-clicked inside the zip, so only this file was unpacked.
powershell -NoProfile -WindowStyle Hidden -Command "try { Add-Type -AssemblyName PresentationFramework; [void][System.Windows.MessageBox]::Show('You need to unpack the download first.' + [Environment]::NewLine + [Environment]::NewLine + 'Close this, right-click the zip file you downloaded, choose ''Extract All...'', then open the new folder and double-click ''Restore Original Game'' there.', 'Restore Original Game', 'OK', 'Information'); exit 0 } catch { exit 1 }" 2>nul
if not errorlevel 1 exit /b 1
rem No PowerShell message box: say it in a new, visible console window instead.
start "Restore Original Game" cmd /c "echo You need to unpack the download first. & echo. & echo Close this window, right-click the zip file you downloaded, choose Extract All, then open the new folder and double-click Restore Original Game there. & echo. & pause"
exit /b 1
