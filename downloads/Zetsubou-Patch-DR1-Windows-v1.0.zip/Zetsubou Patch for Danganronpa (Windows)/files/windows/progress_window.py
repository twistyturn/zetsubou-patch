"""A small native progress window for Windows (ctypes only: user32/gdi32/comctl32).

    win = ProgressWindow("Zetsubou Patch", "This takes a few minutes. ...")
    result = win.run(lambda progress: do_work(progress))   # progress(pct, msg=None)

The constructor creates and shows the window, and raises if anything about that
fails (the caller then works without a window). run() starts `work` in a worker
thread while this thread pumps window messages. The worker never touches a
control: it stores the newest percentage/message and posts a WM_APP message; a
timer in the UI thread is a second way to notice changes, in case a post is
lost. Once the worker has been started, run() always waits for it and returns
its result (or re-raises its exception), whatever happens to the window.

The window can't be closed while the work runs (interrupting a half-written
game file is never safe); it goes away by itself when the work is done.
"""
import ctypes
import threading
from ctypes import wintypes

# pointer-sized Win32 types
HANDLE = ctypes.c_void_p
WPARAM = ctypes.c_size_t
LPARAM = ctypes.c_ssize_t
LRESULT = ctypes.c_ssize_t
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, HANDLE, ctypes.c_uint, WPARAM, LPARAM)

WM_DESTROY, WM_CLOSE, WM_SETFONT, WM_TIMER = 0x0002, 0x0010, 0x0030, 0x0113
WM_APP_PROGRESS, WM_APP_DONE = 0x8001, 0x8002          # WM_APP + 1, + 2
WS_CAPTION, WS_SYSMENU, WS_MINIMIZEBOX = 0x00C00000, 0x00080000, 0x00020000
WS_CHILD, WS_VISIBLE = 0x40000000, 0x10000000
SS_NOPREFIX = 0x0080
PBS_SMOOTH = 0x01
PBM_SETPOS, PBM_SETRANGE32 = 0x0402, 0x0406            # WM_USER + 2, + 6
SC_CLOSE, MF_GRAYED = 0xF060, 0x0001
SPI_GETNONCLIENTMETRICS, SPI_GETWORKAREA = 0x0029, 0x0030
ICC_PROGRESS_CLASS = 0x20
IDC_ARROW, IDI_APPLICATION = 32512, 32512
COLOR_BTNFACE = 15
DEFAULT_GUI_FONT = 17
LOGPIXELSX = 88
SW_SHOWNORMAL = 1
TIMER_ID, TIMER_MS = 1, 200
CLASS_NAME = "ZetsubouPatchProgress"


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint), ("style", ctypes.c_uint),
                ("lpfnWndProc", WNDPROC),
                ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int),
                ("hInstance", HANDLE), ("hIcon", HANDLE), ("hCursor", HANDLE),
                ("hbrBackground", HANDLE),
                ("lpszMenuName", ctypes.c_wchar_p), ("lpszClassName", ctypes.c_wchar_p),
                ("hIconSm", HANDLE)]


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class MSG(ctypes.Structure):
    _fields_ = [("hwnd", HANDLE), ("message", ctypes.c_uint),
                ("wParam", WPARAM), ("lParam", LPARAM),
                ("time", wintypes.DWORD), ("pt", POINT)]


class LOGFONTW(ctypes.Structure):
    _fields_ = [("lfHeight", ctypes.c_long), ("lfWidth", ctypes.c_long),
                ("lfEscapement", ctypes.c_long), ("lfOrientation", ctypes.c_long),
                ("lfWeight", ctypes.c_long),
                ("lfItalic", ctypes.c_ubyte), ("lfUnderline", ctypes.c_ubyte),
                ("lfStrikeOut", ctypes.c_ubyte), ("lfCharSet", ctypes.c_ubyte),
                ("lfOutPrecision", ctypes.c_ubyte), ("lfClipPrecision", ctypes.c_ubyte),
                ("lfQuality", ctypes.c_ubyte), ("lfPitchAndFamily", ctypes.c_ubyte),
                ("lfFaceName", ctypes.c_wchar * 32)]


class NONCLIENTMETRICSW(ctypes.Structure):
    _fields_ = [("cbSize", ctypes.c_uint),
                ("iBorderWidth", ctypes.c_int), ("iScrollWidth", ctypes.c_int),
                ("iScrollHeight", ctypes.c_int), ("iCaptionWidth", ctypes.c_int),
                ("iCaptionHeight", ctypes.c_int), ("lfCaptionFont", LOGFONTW),
                ("iSmCaptionWidth", ctypes.c_int), ("iSmCaptionHeight", ctypes.c_int),
                ("lfSmCaptionFont", LOGFONTW),
                ("iMenuWidth", ctypes.c_int), ("iMenuHeight", ctypes.c_int),
                ("lfMenuFont", LOGFONTW), ("lfStatusFont", LOGFONTW),
                ("lfMessageFont", LOGFONTW), ("iPaddedBorderWidth", ctypes.c_int)]


class INITCOMMONCONTROLSEX(ctypes.Structure):
    _fields_ = [("dwSize", wintypes.DWORD), ("dwICC", wintypes.DWORD)]


def _sig(dll, name, restype, *argtypes):
    fn = getattr(dll, name)
    fn.restype, fn.argtypes = restype, list(argtypes)
    return fn


class _Api:
    """Our own DLL objects (not ctypes.windll's shared ones), with full signatures."""

    def __init__(self):
        c_int, c_uint, BOOL, DWORD, LPCWSTR = (ctypes.c_int, ctypes.c_uint, wintypes.BOOL,
                                               wintypes.DWORD, ctypes.c_wchar_p)
        u = ctypes.WinDLL("user32", use_last_error=True)
        g = ctypes.WinDLL("gdi32", use_last_error=True)
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        self.user32, self.gdi32 = u, g
        self.GetModuleHandleW = _sig(k, "GetModuleHandleW", HANDLE, LPCWSTR)
        self.RegisterClassExW = _sig(u, "RegisterClassExW", ctypes.c_ushort,
                                     ctypes.POINTER(WNDCLASSEXW))
        self.UnregisterClassW = _sig(u, "UnregisterClassW", BOOL, LPCWSTR, HANDLE)
        self.CreateWindowExW = _sig(u, "CreateWindowExW", HANDLE, DWORD, LPCWSTR, LPCWSTR, DWORD,
                                    c_int, c_int, c_int, c_int, HANDLE, HANDLE, HANDLE, HANDLE)
        self.DefWindowProcW = _sig(u, "DefWindowProcW", LRESULT, HANDLE, c_uint, WPARAM, LPARAM)
        self.DestroyWindow = _sig(u, "DestroyWindow", BOOL, HANDLE)
        self.ShowWindow = _sig(u, "ShowWindow", BOOL, HANDLE, c_int)
        self.UpdateWindow = _sig(u, "UpdateWindow", BOOL, HANDLE)
        self.SetForegroundWindow = _sig(u, "SetForegroundWindow", BOOL, HANDLE)
        self.GetMessageW = _sig(u, "GetMessageW", c_int, ctypes.POINTER(MSG), HANDLE,
                                c_uint, c_uint)
        self.TranslateMessage = _sig(u, "TranslateMessage", BOOL, ctypes.POINTER(MSG))
        self.DispatchMessageW = _sig(u, "DispatchMessageW", LRESULT, ctypes.POINTER(MSG))
        self.PostMessageW = _sig(u, "PostMessageW", BOOL, HANDLE, c_uint, WPARAM, LPARAM)
        self.SendMessageW = _sig(u, "SendMessageW", LRESULT, HANDLE, c_uint, WPARAM, LPARAM)
        self.PostQuitMessage = _sig(u, "PostQuitMessage", None, c_int)
        self.SetWindowTextW = _sig(u, "SetWindowTextW", BOOL, HANDLE, LPCWSTR)
        self.SetTimer = _sig(u, "SetTimer", ctypes.c_size_t, HANDLE, ctypes.c_size_t,
                             c_uint, HANDLE)
        self.KillTimer = _sig(u, "KillTimer", BOOL, HANDLE, ctypes.c_size_t)
        self.GetSystemMenu = _sig(u, "GetSystemMenu", HANDLE, HANDLE, BOOL)
        self.EnableMenuItem = _sig(u, "EnableMenuItem", BOOL, HANDLE, c_uint, c_uint)
        self.LoadCursorW = _sig(u, "LoadCursorW", HANDLE, HANDLE, HANDLE)   # MAKEINTRESOURCE id
        self.LoadIconW = _sig(u, "LoadIconW", HANDLE, HANDLE, HANDLE)
        self.GetClientRect = _sig(u, "GetClientRect", BOOL, HANDLE, ctypes.POINTER(RECT))
        self.AdjustWindowRectEx = _sig(u, "AdjustWindowRectEx", BOOL, ctypes.POINTER(RECT),
                                       DWORD, BOOL, DWORD)
        self.SystemParametersInfoW = _sig(u, "SystemParametersInfoW", BOOL, c_uint, c_uint,
                                          ctypes.c_void_p, c_uint)
        self.GetSystemMetrics = _sig(u, "GetSystemMetrics", c_int, c_int)
        self.GetDC = _sig(u, "GetDC", HANDLE, HANDLE)
        self.ReleaseDC = _sig(u, "ReleaseDC", c_int, HANDLE, HANDLE)
        self.GetDeviceCaps = _sig(g, "GetDeviceCaps", c_int, HANDLE, c_int)
        self.GetStockObject = _sig(g, "GetStockObject", HANDLE, c_int)
        self.CreateFontIndirectW = _sig(g, "CreateFontIndirectW", HANDLE,
                                        ctypes.POINTER(LOGFONTW))
        self.DeleteObject = _sig(g, "DeleteObject", BOOL, HANDLE)


class ProgressWindow:
    def __init__(self, title, note, first_status="Getting ready..."):
        self._lock = threading.Lock()
        self._pct, self._msg = 0, first_status
        self._shown = (None, None)            # what the controls currently display
        self._done = False
        self._pumping = False
        self._hwnd = self._status = self._bar = self._note = None
        self._font, self._own_font, self._registered = None, False, False
        self.api = api = _Api()
        self._hinst = api.GetModuleHandleW(None)
        self._wndproc = WNDPROC(self._proc)   # keep a reference: Windows calls into it
        try:
            self._create(title, note)
        except BaseException:
            self._cleanup()
            raise

    # ---- creation (UI thread) ----
    def _scale(self):
        api, dpi = self.api, 0
        try:
            api.user32.SetProcessDPIAware()               # best effort; fine if already set
        except Exception:  # noqa: BLE001
            pass
        try:                                              # Windows 10 1607+
            get = api.user32.GetDpiForSystem
            get.restype, get.argtypes = ctypes.c_uint, []
            dpi = get()
        except Exception:  # noqa: BLE001
            dpi = 0
        if not dpi:
            try:
                dc = api.GetDC(None)
                if dc:
                    dpi = api.GetDeviceCaps(dc, LOGPIXELSX)
                    api.ReleaseDC(None, dc)
            except Exception:  # noqa: BLE001
                dpi = 0
        return dpi / 96.0 if 48 <= dpi <= 960 else 1.0

    def _make_font(self):
        api = self.api
        try:
            ncm = NONCLIENTMETRICSW()
            ncm.cbSize = ctypes.sizeof(NONCLIENTMETRICSW)
            if api.SystemParametersInfoW(SPI_GETNONCLIENTMETRICS, ncm.cbSize,
                                         ctypes.byref(ncm), 0):
                font = api.CreateFontIndirectW(ctypes.byref(ncm.lfMessageFont))
                if font:
                    self._font, self._own_font = font, True
                    return
        except Exception:  # noqa: BLE001
            pass
        self._font = api.GetStockObject(DEFAULT_GUI_FONT)   # may be None: system font then

    def _create(self, title, note):
        api = self.api
        s = self._scale()

        def px(n):
            return int(round(n * s))

        try:
            icc = INITCOMMONCONTROLSEX(ctypes.sizeof(INITCOMMONCONTROLSEX), ICC_PROGRESS_CLASS)
            init = ctypes.WinDLL("comctl32").InitCommonControlsEx
            init.restype, init.argtypes = wintypes.BOOL, [ctypes.POINTER(INITCOMMONCONTROLSEX)]
            init(ctypes.byref(icc))
        except Exception:  # noqa: BLE001  (creating the bar fails below if this mattered)
            pass

        wc = WNDCLASSEXW()
        wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
        wc.lpfnWndProc = self._wndproc
        wc.hInstance = self._hinst
        wc.hIcon = api.LoadIconW(None, IDI_APPLICATION)
        wc.hCursor = api.LoadCursorW(None, IDC_ARROW)
        wc.hbrBackground = COLOR_BTNFACE + 1
        wc.lpszClassName = CLASS_NAME
        if not api.RegisterClassExW(ctypes.byref(wc)):
            raise ctypes.WinError(ctypes.get_last_error())
        self._registered = True

        style = WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX       # fixed size: no resize border
        cw, ch = px(444), px(132)                              # client area
        w, h = px(460), px(170)
        rc = RECT(0, 0, cw, ch)
        if api.AdjustWindowRectEx(ctypes.byref(rc), style, False, 0):
            w, h = rc.right - rc.left, rc.bottom - rc.top
        area = RECT()
        if not api.SystemParametersInfoW(SPI_GETWORKAREA, 0, ctypes.byref(area), 0) \
                or area.right <= area.left or area.bottom <= area.top:
            area = RECT(0, 0, api.GetSystemMetrics(0), api.GetSystemMetrics(1))
        x = area.left + max(0, (area.right - area.left - w) // 2)
        y = area.top + max(0, (area.bottom - area.top - h) // 2)

        self._hwnd = api.CreateWindowExW(0, CLASS_NAME, title, style, x, y, w, h,
                                         None, None, self._hinst, None)
        if not self._hwnd:
            raise ctypes.WinError(ctypes.get_last_error())
        rc = RECT()
        if api.GetClientRect(self._hwnd, ctypes.byref(rc)) and rc.right > 0 and rc.bottom > 0:
            cw, ch = rc.right, rc.bottom

        m = px(16)
        child = WS_CHILD | WS_VISIBLE

        def make(cls, text, extra, top, height):
            hwnd = api.CreateWindowExW(0, cls, text, child | extra, m, top, cw - 2 * m, height,
                                       self._hwnd, None, self._hinst, None)
            if not hwnd:
                raise ctypes.WinError(ctypes.get_last_error())
            return hwnd

        self._status = make("STATIC", self._msg, SS_NOPREFIX, px(14), px(34))
        self._bar = make("msctls_progress32", None, PBS_SMOOTH, px(54), px(20))
        self._note = make("STATIC", note, SS_NOPREFIX, px(88), px(34))

        self._make_font()
        if self._font:
            for hwnd in (self._status, self._note):
                api.SendMessageW(hwnd, WM_SETFONT, self._font, 1)
        api.SendMessageW(self._bar, PBM_SETRANGE32, 0, 100)
        api.SendMessageW(self._bar, PBM_SETPOS, 0, 0)
        self._shown = (0, self._msg)

        menu = api.GetSystemMenu(self._hwnd, False)            # grey out the X while working
        if menu:
            api.EnableMenuItem(menu, SC_CLOSE, MF_GRAYED)
        api.SetTimer(self._hwnd, TIMER_ID, TIMER_MS, None)
        api.ShowWindow(self._hwnd, SW_SHOWNORMAL)
        api.UpdateWindow(self._hwnd)
        api.SetForegroundWindow(self._hwnd)

    # ---- window procedure (UI thread) ----
    def _proc(self, hwnd, msg, wparam, lparam):
        try:
            if msg in (WM_APP_PROGRESS, WM_APP_DONE, WM_TIMER):
                self._refresh()
                if self._done and self._hwnd:
                    self.api.DestroyWindow(self._hwnd)
                return 0
            if msg == WM_CLOSE:
                if self._done:
                    self.api.DestroyWindow(hwnd)
                return 0                                       # not closable while working
            if msg == WM_DESTROY:
                self.api.KillTimer(hwnd, TIMER_ID)
                self._hwnd = None
                if self._pumping:      # otherwise a stray WM_QUIT would close the result box
                    self.api.PostQuitMessage(0)
                return 0
        except Exception:  # noqa: BLE001  (never let an exception escape into Windows)
            pass
        return self.api.DefWindowProcW(hwnd, msg, wparam, lparam)

    def _refresh(self):
        with self._lock:
            pct, text = self._pct, self._msg
        if not self._hwnd:
            return
        if pct != self._shown[0]:
            self.api.SendMessageW(self._bar, PBM_SETPOS, pct, 0)
        if text != self._shown[1]:
            self.api.SetWindowTextW(self._status, text)
        self._shown = (pct, text)

    # ---- called from the worker thread: no control is touched here ----
    def progress(self, pct, msg=None):
        with self._lock:
            self._pct = max(0, min(100, int(pct)))
            if msg:
                self._msg = str(msg)
        self._post(WM_APP_PROGRESS)

    def _post(self, message):
        hwnd = self._hwnd
        if hwnd:
            try:
                self.api.PostMessageW(hwnd, message, 0, 0)
            except Exception:  # noqa: BLE001  (the timer picks the change up instead)
                pass

    # ---- run the work ----
    def run(self, work):
        """Run work(progress) in a worker thread and return what it returns."""
        box = {}

        def target():
            try:
                box["value"] = work(self.progress)
            except BaseException as e:  # noqa: BLE001  (handed back to the caller below)
                box["error"] = e
            finally:
                self._done = True
                self._post(WM_APP_DONE)

        worker = threading.Thread(target=target, name="patch-worker")
        try:
            worker.start()
        except BaseException:
            self._cleanup()            # nothing ran: the caller can still work without us
            raise
        try:
            self._pump()
        except Exception:  # noqa: BLE001  (window trouble must not lose the work's result)
            pass
        worker.join()
        self._cleanup()
        if "error" in box:
            raise box["error"]
        return box.get("value")

    def _pump(self):
        api, msg = self.api, MSG()
        if not self._hwnd:
            return
        self._pumping = True
        try:
            while True:                # ends with the WM_QUIT posted when the window goes
                got = api.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if got <= 0:           # 0 = WM_QUIT, -1 = error
                    break
                api.TranslateMessage(ctypes.byref(msg))
                api.DispatchMessageW(ctypes.byref(msg))
        finally:
            self._pumping = False

    def _cleanup(self):
        api = self.api
        for step in (lambda: self._hwnd and api.DestroyWindow(self._hwnd),
                     lambda: self._registered and api.UnregisterClassW(CLASS_NAME, self._hinst),
                     lambda: self._own_font and self._font and api.DeleteObject(self._font)):
            try:
                step()
            except Exception:  # noqa: BLE001
                pass
        self._hwnd, self._registered, self._own_font = None, False, False
