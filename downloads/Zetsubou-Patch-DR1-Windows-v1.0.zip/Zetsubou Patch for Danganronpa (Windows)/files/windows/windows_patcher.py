#!/usr/bin/env python3
"""Windows front end for the Project Zetsubou patch.

    windows_patcher.py install|restore [--game-dir DIR] [--result FILE]

Finds the game through Steam's registry entry and library list (any drive),
checks whether the game is running, and shows the outcome in a message box.
All patching logic is in core/patchcore.py.

The .bat launchers start this with pythonw.exe, so there is no console: a
small native window (progress_window.py) shows the progress instead, and
everything that would have been printed goes to files/last-run.log. If that
window can't be created for any reason, the patcher simply works without it
and still ends with the message box.

Also usable from a console (python.exe, or any Python for testing): progress
is printed, and the last line is "OK: ..." or "ERROR: ...". --result FILE
additionally writes that outcome to a file (first line OK or ERROR).
ZETSUBOU_NO_DIALOG=1 switches off the window and the message box (tests).
"""
import argparse
import os
import subprocess
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(HERE, "..", "last-run.log")
ON_WINDOWS = os.name == "nt"
DIALOGS = ON_WINDOWS and not os.environ.get("ZETSUBOU_NO_DIALOG")   # off = quiet mode for testing
UNEXPECTED = ("Something unexpected went wrong. Your game was not changed.\n\n"
              "Details are in last-run.log in the patch folder's \"files\" folder.")


def setup_log():
    """pythonw.exe has no console (sys.stdout/stderr are None): write to the log file."""
    if sys.stdout is not None and sys.stderr is not None:
        return
    try:
        if os.path.getsize(LOG) > 2 * 2**20:       # don't let it grow forever
            os.remove(LOG)
    except OSError:
        pass
    try:
        f = open(LOG, "a", encoding="utf-8", errors="replace", buffering=1)
    except OSError:                                # e.g. patch folder on a read-only disc
        f = open(os.devnull, "w", encoding="utf-8", errors="replace")
    if sys.stdout is None:
        sys.stdout = f
    if sys.stderr is None:
        sys.stderr = f
    print(f"\n==== {time.strftime('%Y-%m-%d %H:%M:%S')}  {' '.join(sys.argv[1:])}", flush=True)


def show_message(status, msg, title):
    """Windows message box that stays until closed (falls back to the console)."""
    if not DIALOGS:
        return
    try:
        import ctypes
        icon = 0x40 if status == "OK" else 0x10          # information / error
        ctypes.windll.user32.MessageBoxW(None, msg, title, icon | 0x10000)  # + bring to front
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        try:
            if sys.stdin is not None and sys.stdin.isatty():
                input("\nPress Enter to close.")
        except Exception:  # noqa: BLE001
            pass


def fatal(title="Zetsubou Patch"):
    """An error nothing else caught: record it, tell the player, stop."""
    try:
        traceback.print_exc()
        print(f"\nERROR: {UNEXPECTED}", flush=True)
    except Exception:  # noqa: BLE001
        pass
    show_message("ERROR", UNEXPECTED, title)
    sys.exit(1)


def hide_child_consoles():
    """Without a console of our own, every console program we start (tasklist, the
    video tools) would flash a black window. Start them all windowless."""
    flag = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    if not (ON_WINDOWS and flag):
        return
    original = subprocess.Popen.__init__

    def init(self, *args, **kwargs):
        kwargs["creationflags"] = (kwargs.get("creationflags") or 0) | flag
        original(self, *args, **kwargs)

    subprocess.Popen.__init__ = init


def already_running():
    """True if another copy of the patcher is at work (e.g. a second double-click)."""
    if not ON_WINDOWS:
        return False
    try:
        import ctypes
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.CreateMutexW.restype = ctypes.c_void_p
        k.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_wchar_p]
        ctypes.set_last_error(0)
        handle = k.CreateMutexW(None, False, "ZetsubouPatchForDanganronpaRunning")
        already_running.handle = handle            # kept open until this process ends
        return bool(handle) and ctypes.get_last_error() == 183   # ERROR_ALREADY_EXISTS
    except Exception:  # noqa: BLE001
        return False


setup_log()
try:
    sys.path[:0] = [os.path.join(HERE, "..", "core"), HERE]   # -I leaves the script folder out
    from patchcore import Patcher, Stop, GAME_FOLDER, WAD_NAME  # noqa: E402
except Exception:  # noqa: BLE001  (e.g. an incompletely unpacked download)
    fatal()

_last = [-1, ""]


def progress(pct, msg=None):
    pct = int(pct)
    if msg:
        _last[1] = msg
    # one line per new message, plus a line every 10%, so the console stays readable
    if msg or pct // 10 != _last[0] // 10:
        print(f"[{pct:3d}%] {_last[1]}", flush=True)
    _last[0] = pct


def steam_roots():
    roots = []
    try:
        import winreg
        for hive, key, value in ((winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
                                 (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
                                 (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam", "InstallPath")):
            try:
                with winreg.OpenKey(hive, key) as k:
                    roots.append(os.path.normpath(winreg.QueryValueEx(k, value)[0]))
            except OSError:
                pass
    except ImportError:            # not on Windows (testing)
        pass
    for env in ("ProgramFiles(x86)", "ProgramFiles"):
        if os.environ.get(env):
            roots.append(os.path.join(os.environ[env], "Steam"))
    return list(dict.fromkeys(roots))


def library_paths():
    libs = []
    for root in steam_roots():
        libs.append(root)
        vdf = os.path.join(root, "steamapps", "libraryfolders.vdf")
        try:
            for line in open(vdf, encoding="utf-8", errors="replace"):
                parts = line.strip().split('"')
                if len(parts) >= 4 and parts[1] == "path":
                    libs.append(os.path.normpath(parts[3].replace("\\\\", "\\")))
        except OSError:
            pass
    return list(dict.fromkeys(libs))


def find_game_dir():
    found = []
    for lib in library_paths():
        d = os.path.join(lib, "steamapps", "common", GAME_FOLDER)
        if os.path.isfile(os.path.join(d, WAD_NAME)):
            found.append(os.path.realpath(d))
    found = list(dict.fromkeys(found))
    if not found:
        raise Stop("I couldn't find Danganronpa: Trigger Happy Havoc on this PC.\n\n"
                   "Make sure it's installed through Steam, then try again.")
    if len(found) > 1:
        raise Stop("I found more than one copy of the game:\n\n" + "\n".join(found) +
                   "\n\nPlease uninstall the extra copy in Steam, then try again.")
    return found[0]


def game_running():
    if not ON_WINDOWS:
        return False
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq DR1_us.exe", "/NH"],
                             capture_output=True, text=True, timeout=20,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)).stdout
        return "DR1_us.exe" in out
    except Exception:  # noqa: BLE001
        return False


def run_action(action, game_dir, report):
    """Do the work. Never raises: returns ("OK" | "ERROR", message for the player)."""
    try:
        patcher = Patcher(progress=report, game_running=game_running,
                          restore_hint="To undo it later, double-click \"Restore Original "
                                       "Game\" in the patch folder.")
        game_dir = game_dir or find_game_dir()
        print(f"Game folder: {game_dir}", flush=True)
        msg = patcher.install(game_dir) if action == "install" else patcher.restore(game_dir)
        return "OK", msg
    except Stop as e:
        return "ERROR", str(e)
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        return "ERROR", UNEXPECTED


def run_with_window(action, game_dir, title):
    """Run with the progress window. Returns None if the window isn't available and
    nothing has been done yet (the caller then runs without it)."""
    try:
        from progress_window import ProgressWindow
        note = ("This takes a few minutes. Please don't close this window." if action == "install"
                else "This takes a moment. Please don't close this window.")
        window = ProgressWindow(title, note)
    except Exception:  # noqa: BLE001
        print("(no progress window; carrying on without it)", flush=True)
        traceback.print_exc()
        return None
    started = []

    def work(report):
        started.append(True)

        def both(pct, msg=None):
            progress(pct, msg)         # the log / console
            report(pct, msg)           # the window
        return run_action(action, game_dir, both)

    try:
        return window.run(work)
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        return ("ERROR", UNEXPECTED) if started else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["install", "restore"])
    ap.add_argument("--game-dir")
    ap.add_argument("--result")
    a = ap.parse_args()
    title = "Restore Original Game" if a.action == "restore" else "Zetsubou Patch"
    if already_running():
        print("Another copy of the patcher is already running; leaving it to finish.", flush=True)
        sys.exit(1)
    hide_child_consoles()
    outcome = run_with_window(a.action, a.game_dir, title) if DIALOGS else None
    status, msg = outcome or run_action(a.action, a.game_dir, progress)
    if a.result:
        with open(a.result, "w", encoding="utf-8") as f:
            f.write(status + "\n" + msg)
    print(f"\n{status}: {msg}", flush=True)
    show_message(status, msg, title)
    sys.exit(0 if status == "OK" else 1)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except BaseException:  # noqa: BLE001
        fatal()
