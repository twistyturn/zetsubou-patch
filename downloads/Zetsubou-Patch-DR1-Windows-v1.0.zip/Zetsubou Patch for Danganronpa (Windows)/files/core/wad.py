#!/usr/bin/env python3
"""Read, extract and rebuild Danganronpa PC .wad archives.

Format (from DRAT, CONTAINERS/WAD.cs), all little-endian:
    header   : magic "AGAR", u32 major, u32 minor, u32 unknown
    files    : u32 count, then per file:
                 u32 name_len, name (no NUL), u64 size, u64 offset
    dirs     : u32 count, then per dir:
                 u32 name_len, name, u32 entry_count, then per entry:
                   u32 name_len, name, u8 type (1 = dir, 0 = file)
    data     : file bodies; each offset is relative to the start of data

Rebuilding keeps the header and directory table byte-for-byte and the file
order unchanged; only replaced bodies (and therefore sizes/offsets) change.
So a rebuild with no replacements reproduces the original exactly.

Usage:
    wad.py list    WAD [--grep TEXT]
    wad.py extract WAD OUTDIR [--grep TEXT]
    wad.py rebuild WAD OUT.wad REPLACEDIR   (files under REPLACEDIR, at their
                                             in-WAD paths, replace originals)
    wad.py roundtrip WAD                    (rebuild in memory-light streaming
                                             mode and compare SHA-256)
"""
import argparse
import hashlib
import os
import struct
import sys
from dataclasses import dataclass

MAGIC = b"AGAR"
CHUNK = 1 << 20


@dataclass
class Entry:
    name: str
    size: int
    offset: int  # relative to data start


@dataclass
class Wad:
    path: str
    header: bytes
    entries: list
    dir_table: bytes  # raw bytes of the directory table, kept verbatim
    data_start: int


def _read(f, n):
    b = f.read(n)
    if len(b) != n:
        raise ValueError("unexpected end of file")
    return b


def read_wad(path):
    with open(path, "rb") as f:
        header = _read(f, 16)
        if header[:4] != MAGIC:
            raise ValueError(f"{path}: not a WAD (magic {header[:4]!r})")
        (count,) = struct.unpack("<I", _read(f, 4))
        entries = []
        for _ in range(count):
            (nlen,) = struct.unpack("<I", _read(f, 4))
            name = _read(f, nlen).decode("utf-8")
            size, offset = struct.unpack("<QQ", _read(f, 16))
            entries.append(Entry(name, size, offset))
        dir_start = f.tell()
        (ndirs,) = struct.unpack("<I", _read(f, 4))
        for _ in range(ndirs):
            (nlen,) = struct.unpack("<I", _read(f, 4))
            f.seek(nlen, 1)
            (nsub,) = struct.unpack("<I", _read(f, 4))
            for _ in range(nsub):
                (nlen,) = struct.unpack("<I", _read(f, 4))
                f.seek(nlen + 1, 1)
        data_start = f.tell()
        f.seek(dir_start)
        dir_table = _read(f, data_start - dir_start)
    return Wad(path, header, entries, dir_table, data_start)


def check_layout(wad):
    """Confirm bodies are stored back-to-back in table order (what rebuild assumes)."""
    expected = 0
    for e in wad.entries:
        if e.offset != expected:
            return False
        expected += e.size
    return expected + wad.data_start == os.path.getsize(wad.path)


def read_body(wad, entry):
    with open(wad.path, "rb") as f:
        f.seek(wad.data_start + entry.offset)
        return _read(f, entry.size)


def extract(wad, outdir, grep=None):
    n = 0
    with open(wad.path, "rb") as f:
        for e in wad.entries:
            if grep and grep not in e.name:
                continue
            dest = os.path.join(outdir, e.name)
            if os.path.isabs(e.name) or ".." in e.name.split("/"):
                raise ValueError(f"unsafe path in WAD: {e.name}")
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            f.seek(wad.data_start + e.offset)
            with open(dest, "wb") as out:
                left = e.size
                while left:
                    b = _read(f, min(CHUNK, left))
                    out.write(b)
                    left -= len(b)
            n += 1
    return n


def _write_tables(out, wad, sizes):
    out.write(wad.header)
    out.write(struct.pack("<I", len(wad.entries)))
    offset = 0
    for e, size in zip(wad.entries, sizes):
        name = e.name.encode("utf-8")
        out.write(struct.pack("<I", len(name)) + name + struct.pack("<QQ", size, offset))
        offset += size
    out.write(wad.dir_table)


def rebuild(wad, out_path, replacements):
    """replacements: {in-wad name: path to replacement file}."""
    unknown = set(replacements) - {e.name for e in wad.entries}
    if unknown:
        raise ValueError(f"replacements not in WAD: {sorted(unknown)[:5]}")
    sizes = [os.path.getsize(replacements[e.name]) if e.name in replacements else e.size
             for e in wad.entries]
    with open(wad.path, "rb") as src, open(out_path, "wb") as out:
        _write_tables(out, wad, sizes)
        for e in wad.entries:
            if e.name in replacements:
                with open(replacements[e.name], "rb") as r:
                    while b := r.read(CHUNK):
                        out.write(b)
            else:
                src.seek(wad.data_start + e.offset)
                left = e.size
                while left:
                    b = _read(src, min(CHUNK, left))
                    out.write(b)
                    left -= len(b)


class _HashWriter:
    def __init__(self):
        self.h = hashlib.sha256()

    def write(self, b):
        self.h.update(b)


def roundtrip_hash(wad):
    """SHA-256 of what rebuild() would produce with no replacements, without writing it."""
    hw = _HashWriter()
    _write_tables(hw, wad, [e.size for e in wad.entries])
    with open(wad.path, "rb") as src:
        for e in wad.entries:
            src.seek(wad.data_start + e.offset)
            left = e.size
            while left:
                b = _read(src, min(CHUNK, left))
                hw.write(b)
                left -= len(b)
    return hw.h.hexdigest()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while b := f.read(CHUNK):
            h.update(b)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("list"); s.add_argument("wad"); s.add_argument("--grep")
    s = sub.add_parser("extract"); s.add_argument("wad"); s.add_argument("outdir"); s.add_argument("--grep")
    s = sub.add_parser("rebuild"); s.add_argument("wad"); s.add_argument("out"); s.add_argument("replacedir")
    s = sub.add_parser("roundtrip"); s.add_argument("wad")
    a = p.parse_args()

    wad = read_wad(a.wad)
    if a.cmd == "list":
        for e in wad.entries:
            if not a.grep or a.grep in e.name:
                print(f"{e.size:12d}  {e.name}")
    elif a.cmd == "extract":
        print(f"extracted {extract(wad, a.outdir, a.grep)} files")
    elif a.cmd == "rebuild":
        reps = {}
        for dp, _, files in os.walk(a.replacedir):
            for fn in files:
                full = os.path.join(dp, fn)
                reps[os.path.relpath(full, a.replacedir).replace(os.sep, "/")] = full
        rebuild(wad, a.out, reps)
        print(f"rebuilt {a.out} with {len(reps)} replaced files")
    elif a.cmd == "roundtrip":
        ok_layout = check_layout(wad)
        rebuilt, orig = roundtrip_hash(wad), sha256_file(a.wad)
        print(f"files={len(wad.entries)} contiguous_layout={ok_layout}")
        print(f"original {orig}\nrebuilt  {rebuilt}")
        print("ROUNDTRIP OK" if rebuilt == orig else "ROUNDTRIP MISMATCH")
        sys.exit(0 if rebuilt == orig else 1)


if __name__ == "__main__":
    main()
