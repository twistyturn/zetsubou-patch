#!/usr/bin/env python3
"""DR1 (PC) LIN scripts and PAK containers: parse and rebuild, byte-exact.

LIN (from DRAT, LIN.cs / CommonTextStuff.RePackText), little-endian:
    u32 parts (1 = bytecode only, 2 = bytecode + text)
    u32 header_size (0x10 for 2 parts, 0x0C for 1)
    parts==2: u32 text_offset, u32 file_size
    parts==1: u32 file_size
    bytecode : header_size .. text_offset (or EOF)
    text     : u32 count, u32 ptr[count+1] (relative to text start),
               strings at ptr[i]..ptr[i+1]: BOM FF FE + UTF-16LE + 00 00,
               then zero padding to a 4-byte boundary at EOF.

PAK (PAK.cs): u32 count, u32 offset[count] (absolute), entries at
    offset[i]..offset[i+1] (last runs to EOF); padding to 16 between entries.
    Text paks (00_System.pak etc.) are PAKs whose entries are single
    BOM+UTF-16+NUL strings.

Design rule: anything we can't decode exactly is kept as raw bytes, so a
rebuild with no edits always reproduces the input.
"""
import struct

BOM = b"\xff\xfe"
NUL = b"\x00\x00"


# ---------------------------------------------------------------- strings
class DRString:
    """One string slot. `text` is editable; `pad` is the zero padding that
    followed the terminator in the original slot. If the slot didn't decode
    cleanly, `raw` holds it and `text` is None."""

    __slots__ = ("text", "pad", "raw")

    def __init__(self, text=None, pad=0, raw=None):
        self.text, self.pad, self.raw = text, pad, raw

    @classmethod
    def decode(cls, slot):
        if slot.startswith(BOM):
            body = slot[2:]
            # find the first UTF-16 NUL (on an even offset)
            for i in range(0, len(body) - 1, 2):
                if body[i:i + 2] == NUL:
                    rest = body[i + 2:]
                    if rest.strip(b"\x00") == b"":
                        try:
                            return cls(body[:i].decode("utf-16-le"), len(rest))
                        except UnicodeDecodeError:
                            break
                    break
        return cls(raw=bytes(slot))

    def encode(self, pad_to=None):
        if self.raw is not None:
            return self.raw
        b = BOM + self.text.encode("utf-16-le") + NUL
        if pad_to:
            b += b"\x00" * (-len(b) % pad_to)
        else:
            b += b"\x00" * self.pad
        return b


# ---------------------------------------------------------------- LIN
class Lin:
    def __init__(self, data):
        self.parts, self.header_size = struct.unpack_from("<II", data)
        if self.parts == 2:
            self.text_offset, self.declared_size = struct.unpack_from("<II", data, 8)
        elif self.parts == 1:
            (self.declared_size,) = struct.unpack_from("<I", data, 8)
            self.text_offset = len(data)
        else:
            raise ValueError(f"unexpected LIN part count {self.parts}")
        # Inside a PAK, an entry slice also carries the container's padding
        # after the LIN. Keep it apart so it never leaks into the text block.
        self.outer_pad = b""
        if self.declared_size < len(data) and not data[self.declared_size:].strip(b"\x00"):
            self.outer_pad = bytes(data[self.declared_size:])
            data = data[:self.declared_size]
        if self.parts == 1:
            self.text_offset = len(data)
        self.header = bytes(data[:self.header_size])
        self.bytecode = bytes(data[self.header_size:self.text_offset])
        self.strings = []
        self.text_tail = b""
        self.text_raw = None  # set if the text block isn't in the expected shape
        self.has_text_block = self.parts == 2 and self.text_offset < len(data)
        if self.has_text_block:
            self._parse_text(data[self.text_offset:])

    def _parse_text(self, block):
        try:
            (count,) = struct.unpack_from("<I", block)
            ptrs = struct.unpack_from(f"<{count + 1}I", block, 4)
        except struct.error:
            self.text_raw = bytes(block)
            return
        if ptrs[0] != 4 + 4 * (count + 1) or list(ptrs) != sorted(ptrs) or ptrs[-1] > len(block):
            self.text_raw = bytes(block)
            return
        self.strings = [DRString.decode(block[ptrs[i]:ptrs[i + 1]]) for i in range(count)]
        self.text_tail = bytes(block[ptrs[-1]:])

    def build(self, keep_outer_pad=True):
        out = self._build()
        return out + self.outer_pad if keep_outer_pad else out

    def _build(self):
        if self.parts == 1:
            body = self.bytecode
            out = bytearray(self.header + body)
            struct.pack_into("<I", out, 8, len(out))
            return bytes(out)
        if self.text_raw is not None:
            text = self.text_raw
        elif self.has_text_block:
            slots = [s.encode() for s in self.strings]
            ptr = 4 + 4 * (len(slots) + 1)
            ptrs = []
            for s in slots:
                ptrs.append(ptr)
                ptr += len(s)
            ptrs.append(ptr)
            text = struct.pack(f"<I{len(ptrs)}I", len(slots), *ptrs) + b"".join(slots)
            # tail: original padding if layout unchanged, else re-pad to 4
            tail = self.text_tail
            if (self.header_size + len(self.bytecode) + len(text) + len(tail)) % 4:
                tail = b"\x00" * (-(self.header_size + len(self.bytecode) + len(text)) % 4)
            text += tail
        else:
            text = b""
        out = bytearray(self.header + self.bytecode + text)
        struct.pack_into("<II", out, 8, self.header_size + len(self.bytecode), len(out))
        return bytes(out)


# ---------------------------------------------------------------- PAK
class Pak:
    ALIGN = 16

    def __init__(self, data):
        (count,) = struct.unpack_from("<I", data)
        if count == 0 or 4 + 4 * count > len(data):
            raise ValueError("not a PAK")
        offs = struct.unpack_from(f"<{count}I", data, 4)
        if list(offs) != sorted(offs) or offs[0] < 4 + 4 * count or offs[-1] > len(data):
            raise ValueError("not a PAK (bad offsets)")
        self.table_pad = bytes(data[4 + 4 * count:offs[0]])
        bounds = list(offs) + [len(data)]
        self.entries = [bytes(data[bounds[i]:bounds[i + 1]]) for i in range(count)]

    def build(self):
        head_len = 4 + 4 * len(self.entries)
        first = head_len + len(self.table_pad)
        offs, pos = [], first
        for e in self.entries:
            offs.append(pos)
            pos += len(e)
        return struct.pack(f"<I{len(offs)}I", len(offs), *offs) + self.table_pad + b"".join(self.entries)

    def set_entry(self, i, payload, last=False):
        """Replace entry i, padding to ALIGN unless it's the last entry."""
        if i != len(self.entries) - 1:
            payload += b"\x00" * (-len(payload) % self.ALIGN)
        self.entries[i] = payload


def is_text_pak(pak):
    """True if every entry decodes as a single DR string."""
    return all(DRString.decode(e).text is not None for e in pak.entries)
