"""Platform-independent core of the Project Zetsubou patch.

Everything that decides *what* gets written lives here: the patch data, every
checksum check, applying the text, building the game file, backup and
restore. Front ends (the Steam Deck launcher today, a Windows one later) only
find the game folder, show progress, and display the final message.

    from patchcore import Patcher, Stop
    p = Patcher(progress=lambda pct, msg=None: ..., game_running=lambda: False)
    message = p.install(game_dir)      # or p.restore(game_dir); raises Stop
"""
import base64
import gzip
import hashlib
import json
import os
import shutil
import stat
import sys

from drformats import Lin, Pak, DRString
from imagepaint import paint as paint_image
import videopaint
from wad import read_wad, read_body, _write_tables

HERE = os.path.dirname(os.path.abspath(__file__))
GAME_FOLDER = "Danganronpa Trigger Happy Havoc"
WAD_NAME = "dr1_data_us.wad"
BACKUP = WAD_NAME + ".orig"
TEMP = WAD_NAME + ".zetsubou-tmp"
CHUNK = 1 << 22
VERIFY_HINT = ("In Steam: Danganronpa -> Properties -> Installed Files -> "
               "\"Verify integrity of game files\".")


ANAGRAM_FULL, ANAGRAM_MAGIC = b"\xb4\x00", b"\xd0\x07"
ANAGRAM_FIXED = 22      # type, letter count, magic, answer + extra index, 12 bytes of settings


def anagram_set(data, letters, shown):
    """Epiphany Anagram puzzle (bin/anagram_NN.dat, same layout as SDSE's PSP editor):
    keep the game's own header and settings, set the letter count to our answer's
    length and the letters shown at the start on easy / normal / hard."""
    if data[:2] != ANAGRAM_FULL or data[4:6] != ANAGRAM_MAGIC:
        raise ValueError("not an anagram puzzle file")
    if len(shown) != 3 or any(len(row) != letters for row in shown):
        raise ValueError("need three rows of one flag per letter")
    out = bytearray(data[:2] + letters.to_bytes(2, "little") + data[4:ANAGRAM_FIXED])
    for row in shown:
        for flag in row:
            out += b"\x01\x00" if flag else b"\x00\x00"
    return bytes(out)


def video_tools():
    """vpxdec / vpxenc shipped in the patch folder (files/vpx/<platform>/), libvpx plain-C
    builds that give the same bytes everywhere. ZETSUBOU_VPX_DIR overrides (build tests)."""
    plat = {"win32": "windows-x64", "darwin": "mac"}.get(sys.platform, "linux-x64")
    d = os.environ.get("ZETSUBOU_VPX_DIR") or os.path.join(HERE, "..", "vpx", plat)
    ext = ".exe" if sys.platform == "win32" else ""
    tools = [os.path.join(d, "vpxdec" + ext), os.path.join(d, "vpxenc" + ext)]
    for t in tools:
        if not os.path.isfile(t):
            raise Stop("Part of the patch is missing (the video tools in the \"files\" "
                       "folder).\n\nPlease unpack the download again and retry.")
        if os.name != "nt" and not os.access(t, os.X_OK):
            os.chmod(t, os.stat(t).st_mode | stat.S_IXUSR)
    return tools


class Stop(Exception):
    """A problem we can explain to the user. The game is left unchanged."""


def load_patch(path=None):
    return json.loads(gzip.open(path or os.path.join(HERE, "zetsubou-patch.json.gz")).read())


class Patcher:
    def __init__(self, progress=None, game_running=None, patch=None, restore_hint=""):
        self.progress = progress or (lambda pct, msg=None: None)
        self.game_running = game_running or (lambda: False)
        self.patch = patch or load_patch()
        self.restore_hint = restore_hint  # front end's wording for "how to undo"

    # -------------------------------------------------------------- helpers
    def _sha256(self, path, lo, hi):
        h, size, done = hashlib.sha256(), os.path.getsize(path), 0
        with open(path, "rb") as f:
            while b := f.read(CHUNK):
                h.update(b)
                done += len(b)
                self.progress(lo + (hi - lo) * done / size)
        return h.hexdigest()

    def _check_closed(self):
        if self.game_running():
            raise Stop("Danganronpa is running. Please close the game, then try again.")

    @staticmethod
    def _set_leaf(data, parts, fn):
        pak = Pak(data)
        i = int(parts[0])
        new = fn(pak.entries[i]) if len(parts) == 1 else Patcher._set_leaf(pak.entries[i], parts[1:], fn)
        pak.set_entry(i, new)
        return pak.build()

    @staticmethod
    def apply_file(name, data, spec, workdir=None):
        """Rebuild one script file with the patch's text; verified both ways."""
        if hashlib.sha256(data).hexdigest() != spec["orig_sha256"]:
            raise Stop(f"Part of your game data isn't the version this patch expects:\n{name}\n\n"
                       + VERIFY_HINT)
        if spec["type"] == "tga_paint":
            out = paint_image(data, spec["ops"])
        elif spec["type"] == "video":
            try:
                out = videopaint.reletter(data, spec, *video_tools(), workdir=workdir)
            except (OSError, RuntimeError) as e:
                raise Stop(f"Re-lettering a video didn't work:\n{name}\n{e}\n\n"
                           "Your game is unchanged. Please report this.")
        elif spec["type"] == "anagram":
            out = anagram_set(data, spec["letters"], spec["shown"])
        elif spec["type"] == "pak_tree":
            # images: our generated layers (raw) and paint ops on the player's own copy
            out = data
            for path, b64 in spec.get("raw", {}).items():
                out = Patcher._set_leaf(out, path.split("/"), lambda _, b=b64: base64.b64decode(b))
            for path, ops in spec.get("paint", {}).items():
                out = Patcher._set_leaf(out, path.split("/"), lambda leaf, o=ops: paint_image(leaf, o))
        elif spec["type"] == "lin":
            lin = Lin(data)
            for i, t in spec["strings"].items():
                lin.strings[int(i)].text = t
            out = lin.build()
        else:
            pak = Pak(data)
            if spec["type"] == "pak_raw":
                # our own replacement entries (e.g. re-lettered intro card layers)
                for i, b64 in spec["entries"].items():
                    pak.set_entry(int(i), base64.b64decode(b64))
            elif spec["type"] == "textpak":
                for i, t in spec["strings"].items():
                    s = DRString.decode(pak.entries[int(i)])
                    s.text = t
                    pak.set_entry(int(i), s.encode(pad_to=4))
            else:
                for idx, strings in spec["entries"].items():
                    lin = Lin(pak.entries[int(idx)])
                    for i, t in strings.items():
                        lin.strings[int(i)].text = t
                    pak.set_entry(int(idx), lin.build(keep_outer_pad=False))
            out = pak.build()
        if hashlib.sha256(out).hexdigest() != spec["new_sha256"]:
            raise Stop(f"Patching produced an unexpected result for:\n{name}\n\n"
                       "Nothing was changed. Please report this.")
        return out

    def _build(self, source, dest, replacements, lo, hi):
        wad = read_wad(source)
        sizes = [len(replacements[e.name]) if e.name in replacements else e.size
                 for e in wad.entries]
        total, done = sum(sizes), 0
        with open(source, "rb") as src, open(dest, "wb") as out:
            _write_tables(out, wad, sizes)
            for e in wad.entries:
                if e.name in replacements:
                    out.write(replacements[e.name])
                    done += len(replacements[e.name])
                    continue
                src.seek(wad.data_start + e.offset)
                left = e.size
                while left:
                    b = src.read(min(CHUNK, left))
                    if not b:
                        raise Stop("Your game file ended unexpectedly while reading it.")
                    out.write(b)
                    left -= len(b)
                    done += len(b)
                    self.progress(lo + (hi - lo) * done / total)
            out.flush()
            os.fsync(out.fileno())

    # -------------------------------------------------------------- actions
    def install(self, game_dir):
        p = self.patch
        wad, backup, temp = (os.path.join(game_dir, n) for n in (WAD_NAME, BACKUP, TEMP))
        self._check_closed()
        if os.path.exists(temp):
            os.remove(temp)  # leftover from an interrupted run
        for n in os.listdir(game_dir):     # video scratch folders left by an interrupted run
            if n.startswith(videopaint.TEMP_PREFIX):
                shutil.rmtree(os.path.join(game_dir, n), ignore_errors=True)
        self.progress(1, "Checking your game files...")
        current = self._sha256(wad, 1, 15)
        if current == p["result_sha256"]:
            return "The Zetsubou patch is already installed. Nothing to do!"
        if current == p["original_sha256"]:
            source = wad
        elif os.path.exists(backup):
            self.progress(15, "Checking your backup of the original...")
            if self._sha256(backup, 15, 25) != p["original_sha256"]:
                raise Stop("Your game file isn't the official Steam version, and the backup "
                           "isn't either.\n\n" + VERIFY_HINT + " Then try again.")
            source = backup  # an older version of this patch is installed: update it
        else:
            raise Stop("Your game file isn't the official Steam version this patch was made "
                       "for (maybe another mod is installed?).\n\n" + VERIFY_HINT +
                       " Then try again.")

        free = shutil.disk_usage(game_dir).free
        need = p["result_size"] + 200 * 2**20
        if free < need:
            raise Stop(f"Not enough free space. The patch needs about {need // 2**20} MB free "
                       f"next to the game, and there's {free // 2**20} MB.\n\n"
                       "Free up some space and try again.")

        self.progress(25, "Writing Project Zetsubou's script into the game text...")
        w = read_wad(source)
        index = {e.name: e for e in w.entries}
        replacements = {}
        files = sorted(p["files"].items(), key=lambda kv: kv[1]["type"] == "video")
        videos = sum(1 for _, spec in files if spec["type"] == "video")
        others = len(files) - videos
        for n, (name, spec) in enumerate(files):
            if name not in index:
                raise Stop(f"Your game is missing a file this patch expects:\n{name}")
            if spec["type"] == "video":
                k = n - others
                self.progress(30 + 10 * k / videos,
                              f"Updating the videos ({k + 1} of {videos})...")
            replacements[name] = self.apply_file(name, read_body(w, index[name]), spec,
                                                 workdir=game_dir)
            if n % 50 == 0 and n < others:
                self.progress(25 + 5 * n / max(others, 1))

        self.progress(40, "Building the patched game file...")
        self._build(source, temp, replacements, 40, 80)
        self.progress(80, "Double-checking the result...")
        if self._sha256(temp, 80, 95) != p["result_sha256"]:
            os.remove(temp)
            raise Stop("The patched file didn't come out exactly as expected, so I didn't "
                       "install it. Your game is unchanged. Please report this.")
        try:
            self._check_closed()
        except Stop:
            os.remove(temp)
            raise
        self.progress(96, "Installing...")
        moved = False
        if source == wad and not os.path.exists(backup):
            os.replace(wad, backup)  # keep the original
            moved = True
        try:
            os.replace(temp, wad)
        except OSError:
            if moved:                # never leave the game without its data file
                os.replace(backup, wad)
            try:
                os.remove(temp)
            except OSError:
                pass
            raise Stop("I couldn't put the patched file in place (another program may be "
                       "using the game folder, like a virus scan). Your game is unchanged.\n\n"
                       "Wait a minute and try again.")
        self.progress(100, "Done!")
        return ("Done! Project Zetsubou's script is installed.\n\n"
                "Launch Danganronpa from Steam as usual. Your saves still work.\n\n"
                "Tip: set the voices to Japanese in the game's Options. Project "
                "Zetsubou translated from the Japanese, so the text matches what "
                "you hear (the English dub follows the official script)."
                + (f"\n\n{self.restore_hint}" if self.restore_hint else ""))

    def restore(self, game_dir):
        p = self.patch
        wad, backup = os.path.join(game_dir, WAD_NAME), os.path.join(game_dir, BACKUP)
        self._check_closed()
        self.progress(1, "Checking your game files...")
        if os.path.exists(backup):
            if self._sha256(backup, 1, 90) != p["original_sha256"]:
                raise Stop("The backup file doesn't match the official game, so I left "
                           "everything alone.\n\n" + VERIFY_HINT + " That restores the original.")
            self._check_closed()
            os.replace(backup, wad)
            self.progress(100, "Done!")
            return "Done! Your game is back to the original official English script."
        if self._sha256(wad, 1, 95) == p["original_sha256"]:
            self.progress(100)
            return "Your game is already the original official version. Nothing to do."
        raise Stop("I couldn't find the backup this patch makes.\n\n" + VERIFY_HINT +
                   " That restores the original.")
