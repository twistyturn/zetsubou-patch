"""Re-letter text burned into the game's VP8 videos, on the player's own copy.

The execution videos open with a "GAME OVER" card whose text types out in a
monospaced pixel font on plain black ("CELESTE HAS BEEN FOUND GUILTY."). We
rebuild that line from the letters already in the player's frames: each cell
of the new line is a copy of a cell of the old one (same frame when it has
appeared; otherwise a reference frame), so the patch carries only positions
and timings, never pixels.

Only a keyframe-to-keyframe stretch is re-encoded and spliced back, so the
rest of the video is untouched. vpxdec / vpxenc (libvpx, plain-C build) do
the decoding and encoding; everything here is integer math, so every machine
produces the same frames, and the same libvpx build the same file.
"""
import os
import shutil
import struct
import subprocess
import tempfile

TEMP_PREFIX = ".zetsubou-video-"   # scratch folders next to the game; leftovers are removed

IVF_HEADER = 32


def ivf_packets(data):
    hl = struct.unpack_from("<H", data, 6)[0]
    out, p = [], hl
    while p < len(data):
        size = struct.unpack_from("<I", data, p)[0]
        out.append((data[p + 4:p + 12], data[p + 12:p + 12 + size]))
        p += 12 + size
    return data[:hl], out


def ivf_join(header, packets):
    out = bytearray(header)
    struct.pack_into("<I", out, 24, len(packets))
    for ts, frame in packets:
        out += struct.pack("<I", len(frame)) + ts + frame
    return bytes(out)


class Frame:
    """One I420 frame: Y plane (w*h) then U, V (w/2*h/2 each)."""

    def __init__(self, raw, w, h):
        self.w, self.h = w, h
        self.buf = bytearray(raw)

    def y_rect(self, x0, y0, x1, y1):
        w = self.w
        return [bytes(self.buf[r * w + x0:r * w + x1]) for r in range(y0, y1)]

    def put_y_rect(self, x0, y0, rows):
        w = self.w
        for i, row in enumerate(rows):
            o = (y0 + i) * w + x0
            self.buf[o:o + len(row)] = row

    def fill(self, x0, y0, x1, y1, yv, uv=128):
        w, h = self.w, self.h
        line = bytes([yv]) * (x1 - x0)
        for r in range(y0, y1):
            self.buf[r * w + x0:r * w + x1] = line
        cw, plane = w // 2, w * h // 4
        cx0, cx1 = x0 // 2, (x1 + 1) // 2
        cline = bytes([uv]) * (cx1 - cx0)
        for base in (w * h, w * h + plane):
            for r in range(y0 // 2, (y1 + 1) // 2):
                self.buf[base + r * cw + cx0:base + r * cw + cx1] = cline


def lit(rows, threshold):
    """Number of pixels brighter than threshold (has this letter appeared yet?)."""
    return sum(1 for row in rows for v in row if v > threshold)


def relayout_line(frame, ref, op):
    """Rebuild one line of monospaced pixel text.

    op: y0, y1          rows of the line (with margin)
        x0, x1          span to clear (old line, with margin)
        bg              background luma
        cell_w          width copied per cell (pitch, integer)
        cells           [[dst_x, src_x, time_x], ...]: copy the cell at src_x to
                        dst_x once the old cell at time_x has appeared
        threshold, min_lit   "has appeared" test
    """
    y0, y1 = op["y0"], op["y1"]
    old = frame.y_rect(op["x0"], y0, op["x1"], y1)
    cw = op["cell_w"]

    def cell(rows, x):
        a = x - op["x0"]
        return [r[a:a + cw] for r in rows]

    shown = []
    for dst, src, tim in op["cells"]:
        if lit(cell(old, tim), op["threshold"]) >= op["min_lit"]:
            pix = cell(old, src)
            if lit(pix, op["threshold"]) < op["min_lit"]:      # source letter not typed yet
                pix = ref.y_rect(src, y0, src + cw, y1)
            shown.append((dst, pix))
    frame.fill(op["x0"], y0, op["x1"], y1, op["bg"])
    for dst, pix in shown:
        frame.put_y_rect(dst, y0, pix)


def run(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, **kw)
    if r.returncode != 0:
        raise RuntimeError(f"{os.path.basename(cmd[0])} failed: {r.stderr.decode(errors='replace')[-400:]}")
    return r


def reletter(data, spec, vpxdec, vpxenc, workdir=None):
    """Return the video with each spec segment re-lettered and spliced back."""
    vpxdec, vpxenc = os.path.abspath(vpxdec), os.path.abspath(vpxenc)   # tools run in tmp
    header, packets = ivf_packets(data)
    w, h = struct.unpack_from("<HH", header, 12)
    fsize = w * h * 3 // 2
    for seg in spec["segments"]:
        a, b = seg["start"], seg["end"]
        # Our own scratch folder (ASCII name). The libvpx tools get bare file names and run
        # inside it: their main() can't open non-ASCII paths on Windows, and vpxdec treats
        # "%" in its output name as a pattern.
        tmp = tempfile.mkdtemp(prefix=TEMP_PREFIX, dir=workdir)
        try:
            sub = [(struct.pack("<Q", i), fr) for i, (_, fr) in enumerate(packets[a:b])]
            with open(os.path.join(tmp, "cut.ivf"), "wb") as f:
                f.write(ivf_join(header, sub))
            run([vpxdec, "--i420", "-o", "frames.yuv", "cut.ivf"], cwd=tmp)
            raw = os.path.join(tmp, "frames.yuv")
            if os.path.getsize(raw) != fsize * (b - a):
                raise RuntimeError("decoded frame count doesn't match")
            with open(raw, "r+b") as f:
                f.seek(seg["ref"] * fsize)
                ref = Frame(f.read(fsize), w, h)
                for op in seg["ops"]:
                    for i in range(op["from"], op["to"]):
                        f.seek(i * fsize)
                        fr = Frame(f.read(fsize), w, h)
                        if op["type"] == "relayout_line":
                            relayout_line(fr, ref, op)
                        else:
                            raise ValueError(op["type"])
                        f.seek(i * fsize)
                        f.write(fr.buf)
            run([vpxenc, *seg["vpxenc"], "-w", str(w), "-h", str(h), "--i420", "--ivf",
                 "-o", "new.ivf", "frames.yuv"], cwd=tmp)
            with open(os.path.join(tmp, "new.ivf"), "rb") as f:
                _, new = ivf_packets(f.read())
        finally:
            # a virus scanner may still hold a file we just closed: never fail over cleanup
            shutil.rmtree(tmp, ignore_errors=True)
        if len(new) != b - a or (new[0][1][0] & 1):
            raise RuntimeError("re-encoded segment doesn't fit")
        packets[a:b] = [(ts, fr) for (ts, _), (_, fr) in zip(packets[a:b], new)]
    if spec.get("trim"):
        # keep only the first frames (the cut must land on a keyframe boundary): the
        # opening movie plays unskippably on every launch on the Steam Deck
        n = spec["trim"]
        if n >= len(packets) or (packets[n][1][0] & 1):
            raise RuntimeError("video can't be shortened at that frame")
        packets = packets[:n]
    return ivf_join(header, packets)
