"""Paint fixes onto the player's own game images (shared by build and patcher).

A paint job is a list of ops applied to one TGA image:
    {"fill": [x, y, w, h, r, g, b, a]}         solid rectangle (e.g. page white)
    {"draw": [x, y, w, h, "<base64 RGBA>"]}     our lettering, alpha-blended
    {"interp": [x, y, w, h]}                     rebuild a rectangle from the image's own
                                                 pixels just left/right of it, row by row
                                                 (erases old text on gradients)
    {"inpaint": [x, y, w, h, thr, grow(, band)]} erase only bright lettering (or, with a
                                                 negative thr, dark lettering) inside the
                                                 rectangle (min channel > thr, grown by
                                                 `grow` px), refilling each run from the
                                                 untouched pixels either side; keeps
                                                 watermarks and texture between letters;
                                                 band [ax, ay, cos, sin, lo, hi(, ulo, uhi)]
                                                 (integers: cos/sin x1000, bounds x1000 px)
                                                 limits it to a tilted strip, optionally
                                                 also along it (one line of slanted text);
                                                 a list of bands = their intersection;
                                                 "gray": n on the op skips pixels whose
                                                 channels differ by more than n (colored)
    {"inpaint_rel": [x, y, w, h, delta, grow(, fx, fy, slope)]}
                                                 like inpaint for dark lettering, but "dark"
                                                 means darker than the rectangle's own
                                                 border (median luminance) by `delta`;
                                                 adapts to any background color; the
                                                 optional floor line keeps pixels below
                                                 y = fy + slope*(x-fx) untouched
    {"vinterp": [x, y, w, h]}                    same, but from the pixels just above/below
                                                 (removes thin horizontal lines)
    {"copy": [sx, sy, w, h, dx, dy]}             move a block of the image's own pixels
                                                 (e.g. spread pixel-font letters apart)
For palette (type 1) images, every touched pixel is mapped to the nearest
color already in that image's palette; untouched pixels keep their index, so
the palette and file layout don't change. The result is deterministic, so the
patcher can verify it against the expected SHA-256.
"""
import base64
import struct


def _hdr(b):
    idl, cmt, it, cfirst, clen, cbits, _, _, w, h, bpp, desc = struct.unpack_from("<BBBHHBHHHHBB", b)
    pal_off = 18 + idl
    pix_off = pal_off + (clen * cbits // 8 if cmt else 0)
    return dict(type=it, w=w, h=h, bpp=bpp, desc=desc, clen=clen, cbits=cbits,
                pal_off=pal_off, pix_off=pix_off)


def _palette(b, hd):
    step = hd["cbits"] // 8
    p = b[hd["pal_off"]:hd["pal_off"] + hd["clen"] * step]
    return [(p[i * step + 2], p[i * step + 1], p[i * step], p[i * step + 3] if step == 4 else 255)
            for i in range(hd["clen"])]


def paint(tga, ops):
    hd = _hdr(tga)
    w, h = hd["w"], hd["h"]
    flip = not hd["desc"] & 0x20          # bottom-left origin
    out = bytearray(tga)
    if hd["type"] == 1:
        pal = _palette(tga, hd)
        get_ = lambda x, y: pal[tga[hd["pix_off"] + ((h - 1 - y) if flip else y) * w + x]]  # noqa: E731
    elif hd["type"] == 2:
        step = hd["bpp"] // 8

        def get_(x, y):
            o = hd["pix_off"] + (((h - 1 - y) if flip else y) * w + x) * step
            p = tga[o:o + step]
            return (p[2], p[1], p[0], p[3] if step == 4 else 255)
    else:
        raise ValueError("unsupported TGA type")

    def get(x, y):        # reads past the edge repeat the edge pixel
        return get_(min(w - 1, max(0, x)), min(h - 1, max(0, y)))

    cur = {}                               # (x, y) -> RGBA for touched pixels
    for op in ops:
        if "inpaint_rel" in op:
            x0, y0, iw, ih, delta, grow = op["inpaint_rel"][:6]
            # optional floor: only pixels above the line y = fy + fs * (x - fx) are erased
            floor = op["inpaint_rel"][6:9] if len(op["inpaint_rel"]) >= 9 else None
            px = lambda X, Y: cur.get((X, Y)) or get(X, Y)
            lum = lambda c: (299 * c[0] + 587 * c[1] + 114 * c[2]) // 1000
            border = sorted(lum(px(x, y)) for x in range(x0 - 1, x0 + iw + 1) for y in (y0 - 1, y0 + ih)
                            if 0 <= x < w and 0 <= y < h)
            border += sorted(lum(px(x, y)) for y in range(y0, y0 + ih) for x in (x0 - 1, x0 + iw)
                             if 0 <= x < w and 0 <= y < h)
            ref = sorted(border)[len(border) // 2]
            # letters have near-black cores; background pattern lines don't. Only
            # pixels within 2 px of a core count, so patterns behind the text survive.
            cores = {(x, y) for y in range(y0, y0 + ih) for x in range(x0, x0 + iw)
                     if lum(px(x, y)) < ref * 0.45}
            near = {(x + dx, y + dy) for (x, y) in cores for dx in range(-2, 3) for dy in range(-2, 3)}
            op = {"inpaint": [x0, y0, iw, ih, None, grow], "_floor": floor,
                  "_mask": None, "_near": near, "_dark": lambda c: lum(c) < ref - delta}
        if "inpaint" in op:
            x0, y0, iw, ih, thr, grow = op["inpaint"][:6]
            band = op["inpaint"][6] if len(op["inpaint"]) > 6 else None
            px = lambda X, Y: cur.get((X, Y)) or get(X, Y)
            test = op.get("_mask") or ((lambda c: min(c[:3]) > thr) if (thr or 0) >= 0 else (lambda c: max(c[:3]) < -thr))
            if op.get("gray") is not None:     # lettering is gray/white: skip colored pixels
                base_test, gray = test, op["gray"]
                test = lambda c: base_test(c) and max(c[:3]) - min(c[:3]) <= gray  # noqa: E731
            fl = op.get("_floor")
            below = (lambda x, y: y > fl[1] + fl[2] * (x - fl[0])) if fl else (lambda x, y: False)
            if band:   # only inside tilted strip(s), integer math (same on every machine)
                strips = band if isinstance(band[0], list) else [band]
                fl_below = below

                def outside(x, y, st):
                    ax, ay, c, s_, lo, hi = st[:6]   # c, s_ = cos, sin of the tilt x 1000
                    if not lo <= -(x - ax) * s_ + (y - ay) * c <= hi:
                        return True
                    return len(st) >= 8 and not st[6] <= (x - ax) * c + (y - ay) * s_ <= st[7]

                def below(x, y, fl_below=fl_below):
                    return fl_below(x, y) or any(outside(x, y, st) for st in strips)
            if op.get("_near") is not None:
                near, dark = op["_near"], op["_dark"]
                hit = {(x, y) for (x, y) in near if x0 <= x < x0 + iw and y0 <= y < y0 + ih
                       and not below(x, y) and dark(px(x, y))}
            else:
                hit = {(x, y) for y in range(y0, y0 + ih) for x in range(x0, x0 + iw)
                       if not below(x, y) and test(px(x, y))}
            mask = set()
            for (x, y) in hit:
                for dy in range(-grow, grow + 1):
                    for dx in range(-grow, grow + 1):
                        if x0 <= x + dx < x0 + iw and y0 <= y + dy < y0 + ih and not below(x + dx, y + dy):
                            mask.add((x + dx, y + dy))
            new = {}
            for y in range(y0, y0 + ih):
                x = x0
                while x < x0 + iw:
                    if (x, y) not in mask:
                        x += 1
                        continue
                    s0 = x
                    while x < x0 + iw and (x, y) in mask:
                        x += 1
                    a, b = px(s0 - 1, y), px(x, y)
                    n = x - s0
                    for k in range(n):
                        t = (k + 1) / (n + 1)
                        new[(s0 + k, y)] = tuple(round(a[c] * (1 - t) + b[c] * t) for c in range(4))
            cur.update(new)
        elif "interp" in op:
            x0, y0, iw, ih = op["interp"]
            for y in range(y0, y0 + ih):
                a = cur.get((x0 - 1, y)) or get(x0 - 1, y)
                b = cur.get((x0 + iw, y)) or get(x0 + iw, y)
                for x in range(x0, x0 + iw):
                    t = (x - x0 + 1) / (iw + 1)
                    cur[(x, y)] = tuple(round(a[k] * (1 - t) + b[k] * t) for k in range(4))
        elif "vinterp" in op:
            x0, y0, iw, ih = op["vinterp"]
            for x in range(x0, x0 + iw):
                a = cur.get((x, y0 - 1)) or get(x, y0 - 1)
                b = cur.get((x, y0 + ih)) or get(x, y0 + ih)
                for y in range(y0, y0 + ih):
                    t = (y - y0 + 1) / (ih + 1)
                    cur[(x, y)] = tuple(round(a[k] * (1 - t) + b[k] * t) for k in range(4))
        elif "copy" in op:
            sx, sy, cw, ch, dx, dy = op["copy"]
            block = {(x, y): cur.get((sx + x, sy + y)) or get(sx + x, sy + y)
                     for y in range(ch) for x in range(cw)}
            for (x, y), c in block.items():
                if 0 <= dx + x < w and 0 <= dy + y < h:
                    cur[(dx + x, dy + y)] = c
        elif "fill" in op:
            x0, y0, fw, fh, r, g, b, a = op["fill"]
            for y in range(y0, y0 + fh):
                for x in range(x0, x0 + fw):
                    cur[(x, y)] = (r, g, b, a)
        else:
            x0, y0, dw, dh, data = op["draw"]
            src = base64.b64decode(data)
            for y in range(dh):
                for x in range(dw):
                    sr, sg, sb, sa = src[(y * dw + x) * 4:(y * dw + x) * 4 + 4]
                    if not sa:
                        continue
                    X, Y = x0 + x, y0 + y
                    if not (0 <= X < w and 0 <= Y < h):
                        continue
                    dr, dg, db, da = cur.get((X, Y)) or get(X, Y)
                    t = sa / 255
                    cur[(X, Y)] = (round(sr * t + dr * (1 - t)), round(sg * t + dg * (1 - t)),
                                   round(sb * t + db * (1 - t)), max(da, sa))

    if hd["type"] == 1:
        cache = {}
        def nearest(c):
            if c not in cache:
                cache[c] = min(range(len(pal)), key=lambda i: sum((pal[i][k] - c[k]) ** 2 for k in range(4)))
            return cache[c]
        for (x, y), c in cur.items():
            out[hd["pix_off"] + ((h - 1 - y) if flip else y) * w + x] = nearest(c)
    else:
        step = hd["bpp"] // 8
        for (x, y), (r, g, b, a) in cur.items():
            o = hd["pix_off"] + (((h - 1 - y) if flip else y) * w + x) * step
            out[o:o + step] = bytes((b, g, r, a))[:step]
    return bytes(out)
