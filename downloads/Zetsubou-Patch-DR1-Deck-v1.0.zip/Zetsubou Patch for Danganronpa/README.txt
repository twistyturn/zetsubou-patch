PROJECT ZETSUBOU SCRIPT FOR DANGANRONPA: TRIGGER HAPPY HAVOC
Steam Deck patch, version 1.0
==============================================================

This puts Project Zetsubou's 2013 fan translation of Danganronpa into the
Steam version of the game, so you can play it on your Steam Deck.

(This download is the Steam Deck version. Playing on a Windows PC
instead? That needs the PC version of the installer.)

You need:
  - Danganronpa: Trigger Happy Havoc from Steam, installed on your Deck
    (internal storage or SD card both work)
  - About 1.5 GB of free space where the game is installed

The patch contains only text and lettering. It doesn't include any of the
game's own files, so it works on your own copy of the game.


INSTALLING
----------

1. Switch to Desktop Mode
   Press the STEAM button -> Power -> Switch to Desktop.

2. Unpack the download
   Open the file manager (the blue folder icon in the taskbar) and go to
   your Downloads folder. Right-click the patch zip file and choose
   "Extract" -> "Extract archive here".
   You'll get a folder called "Zetsubou Patch for Danganronpa".

3. Run the installer
   Open that folder and double-click "Install Zetsubou Patch".
   (If your Deck asks whether to run it, choose Run / Execute / Continue.)

   A window shows the progress. It takes a few minutes. When it's done,
   a message says "Done!". Close that window.

4. Play
   Go back to Gaming Mode (there's a "Return to Gaming Mode" icon on the
   desktop) and start Danganronpa as usual.

Your existing saves keep working, with or without the patch.

Tip: set the voices to Japanese in the game's Options. Project Zetsubou
translated from the Japanese, so their text matches what you hear. The
English dub was recorded for the official script, so with English voices
the spoken lines often won't match the text on screen.


IF DOUBLE-CLICKING DOESN'T WORK
-------------------------------

If double-clicking "Install Zetsubou Patch" opens it as a text file, or
nothing happens:

  1. Right-click "Install Zetsubou Patch" -> Properties.
  2. Open the "Permissions" tab and tick "Is executable".
  3. Click OK, then double-click it again.

Do the same for "Restore Original Game" if you need it.

Last resort: open Konsole (Application Launcher -> System -> Konsole),
paste this line, and press Enter:

  bash ~/Downloads/"Zetsubou Patch for Danganronpa"/files/deck/run.sh install

(If you extracted the folder somewhere other than Downloads, change the
path to match.)


GOING BACK TO THE ORIGINAL GAME
-------------------------------

Double-click "Restore Original Game" in the patch folder. It puts back
the original file that the installer kept as a backup.

Steam can also do this: in your Library, Danganronpa -> Properties ->
Installed Files -> "Verify integrity of game files". Note that this
also removes the patch, so if you ever run it by accident, just run
"Install Zetsubou Patch" again.


IF SOMETHING GOES WRONG
-----------------------

The patcher checks everything before it changes anything. If a check
fails, your game is left exactly as it was, and the message tells you
what to do. Common ones:

  - "Danganronpa is running": close the game and try again.
  - "isn't the official Steam version": another mod may be installed.
    Use "Verify integrity of game files" in Steam, then try again.
  - "Not enough free space": free up some space and try again.

A record of each run is saved in files/last-run.log inside the patch
folder. If you need help, send that file along.


ABOUT THIS PATCH
----------------

Translation: Project Zetsubou (2013), from their public script release.
This patch carries their script over to the Steam version of the game,
as faithfully as possible. Every change is recorded line by line in the
project files. In short:

  - Lines are Project Zetsubou's, except for a small number of fixes:
    slurs and sexual content that the translation added (and that
    aren't in the Japanese), a few lines that misread the Japanese, and
    puns that didn't survive the first time.
  - Places the Steam version added (School Mode, some extra items and
    menus) keep the official English text, with names and terms
    matched to Project Zetsubou's (Hope's Peak, ElectroiD, Kyouko,
    Super Duper High School...).
  - Control and button instructions keep the official text, so the
    button prompts are always right for the Deck.
  - On-screen graphics that spell out names and terms were re-lettered
    to match: the student intro cards and gallery icons, name tags,
    chapter titles, the ElectroiD menu and School Rules pages, the dorm
    door nameplates, Naegi's acceptance letter, a few banners, and the
    names on the executions' GAME OVER screens. The
    patch only carries the new lettering; it's painted onto your own
    copy of the game when you install.
  - Epiphany Anagram puzzles are adjusted so Project Zetsubou's answers
    fit (for example, Chapter 2's answer is DID).
  - The opening movie that plays every time the game starts is cut to
    about three seconds, because it can't be skipped with a controller
    on the Steam Deck. (The "Opening" entry in the Movie Gallery is
    shortened too. Restoring the original game brings it back.)

This is a fan project. It isn't affiliated with or endorsed by Spike
Chunsoft, NIS America, or Project Zetsubou. Please support the official
release.

Bundled: vpxdec/vpxenc from libvpx 1.15.2 (the WebM Project's VP8 video
codec, used to re-letter the videos), under the BSD license in files/vpx/.
