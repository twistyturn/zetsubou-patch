#!/usr/bin/env python3
"""Steam Deck front end for the Project Zetsubou patch.

    deck_patcher.py install|restore [--game-dir DIR] [--result FILE]

Finds the game in the Deck's Steam libraries (internal or SD card), checks
whether it's running, and reports progress in zenity's format ("NN" and
"# message" lines on stdout). The outcome goes to --result: first line OK or
ERROR, then the message. All patching logic is in core/patchcore.py.
"""
import argparse
import glob
import os
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "core"))
from patchcore import Patcher, Stop, GAME_FOLDER, WAD_NAME  # noqa: E402


def progress(pct, msg=None):
    print(int(pct), flush=True)
    if msg:
        print("# " + msg, flush=True)


def library_paths():
    paths = []
    for vdf in (os.path.expanduser("~/.local/share/Steam/steamapps/libraryfolders.vdf"),
                os.path.expanduser("~/.steam/steam/steamapps/libraryfolders.vdf")):
        try:
            for line in open(vdf, encoding="utf-8", errors="replace"):
                parts = line.strip().split('"')
                if len(parts) >= 4 and parts[1] == "path":
                    paths.append(parts[3])
        except OSError:
            pass
    return paths + glob.glob("/run/media/*") + glob.glob("/run/media/*/*")


def find_game_dir():
    found = []
    for lib in library_paths():
        d = os.path.join(lib, "steamapps", "common", GAME_FOLDER)
        if os.path.isfile(os.path.join(d, WAD_NAME)):
            found.append(os.path.realpath(d))
    found = list(dict.fromkeys(found))
    if not found:
        raise Stop("I couldn't find Danganronpa: Trigger Happy Havoc on this Deck.\n\n"
                   "Make sure it's installed through Steam (internal storage or SD card), "
                   "then try again.")
    if len(found) > 1:
        raise Stop("I found more than one copy of the game:\n\n" + "\n".join(found) +
                   "\n\nPlease uninstall the extra copy in Steam, then try again.")
    return found[0]


def game_running():
    for cmd in glob.glob("/proc/[0-9]*/cmdline"):
        try:
            if b"DR1_us.exe" in open(cmd, "rb").read():
                return True
        except OSError:
            pass
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("action", choices=["install", "restore"])
    ap.add_argument("--game-dir")
    ap.add_argument("--result")
    a = ap.parse_args()
    try:
        patcher = Patcher(progress=progress, game_running=game_running,
                          restore_hint="To undo it later, double-click \"Restore Original "
                                       "Game\" in the patch folder.")
        game_dir = a.game_dir or find_game_dir()
        msg = patcher.install(game_dir) if a.action == "install" else patcher.restore(game_dir)
        status = "OK"
    except Stop as e:
        status, msg = "ERROR", str(e)
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        status = "ERROR"
        msg = ("Something unexpected went wrong. Your game was not changed.\n\n"
               "Details are in last-run.log in the patch folder's \"files\" folder.")
    progress(100)
    if a.result:
        with open(a.result, "w", encoding="utf-8") as f:
            f.write(status + "\n" + msg)
    else:
        print(f"\n{status}: {msg}")
    sys.exit(0 if status == "OK" else 1)


if __name__ == "__main__":
    main()
