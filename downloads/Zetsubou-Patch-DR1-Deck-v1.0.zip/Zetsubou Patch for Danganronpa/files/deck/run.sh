#!/bin/bash
# Steam Deck launcher for the Project Zetsubou patch.
#   run.sh install | restore
# Runs the patcher behind a progress window, then shows the result in a window
# that stays open until it's closed. Without a desktop session it prints to
# the terminal instead. Everything is also appended to files/last-run.log.
set -u

FILES="$(cd "$(dirname "$0")/.." && pwd)"
ACTION="${1:-install}"
LOG="$FILES/last-run.log"
RESULT="$(mktemp)"
trap 'rm -f "$RESULT"' EXIT

if [ "$ACTION" = "restore" ]; then TITLE="Restore Original Game"; else TITLE="Zetsubou Patch"; fi
echo "=== $(date '+%Y-%m-%d %H:%M:%S') $ACTION" >>"$LOG"

has_gui() { [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; }
has() { command -v "$1" >/dev/null 2>&1; }

show() {  # show STATUS MESSAGE
    local status="$1" msg="$2"
    if has_gui && has zenity; then
        local kind="--info"; [ "$status" = "OK" ] || kind="--error"
        local markup=()
        zenity --help-info 2>/dev/null | grep -q -- "--no-markup" && markup=(--no-markup)
        zenity "$kind" --title="$TITLE" --width=480 "${markup[@]}" --text="$msg" 2>>"$LOG" && return
    fi
    if has_gui && has kdialog; then
        if [ "$status" = "OK" ]; then kdialog --title "$TITLE" --msgbox "$msg"
        else kdialog --title "$TITLE" --error "$msg"; fi
        return
    fi
    printf '\n%s\n\n%s\n\nPress Enter to close.' "$status" "$msg"
    read -r _
}

if ! has python3; then
    show ERROR "This Deck doesn't seem to have Python 3, which the patcher needs. Please report this."
    exit 1
fi

PATCHER=(python3 -I "$FILES/deck/deck_patcher.py" "$ACTION" --result "$RESULT")
if has_gui && has zenity; then
    "${PATCHER[@]}" 2>>"$LOG" | zenity --progress --title="$TITLE" --text="Starting..." \
        --percentage=0 --auto-close --no-cancel --width=520 2>>"$LOG"
else
    "${PATCHER[@]}" 2>>"$LOG" | grep --line-buffered '^# ' | sed -u 's/^# /  /'
fi

STATUS="$(head -n 1 "$RESULT" 2>/dev/null)"
MESSAGE="$(tail -n +2 "$RESULT" 2>/dev/null)"
if [ -z "$STATUS" ]; then
    STATUS="ERROR"
    MESSAGE="The patcher stopped unexpectedly. Your game was not changed.

Details are in last-run.log in the \"files\" folder."
fi
echo "$STATUS: $MESSAGE" >>"$LOG"
show "$STATUS" "$MESSAGE"
[ "$STATUS" = "OK" ]
